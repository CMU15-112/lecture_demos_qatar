from cmu_graphics import *
import math
import numpy as np
class CameraSystem:
    def __init__(self, app):
        self.app = app
        self.screenMultiplier = 1
        self.x = app.width // 2
        self.y = app.height // 2
        self.zoomLevel = 0.8
        self.old_zoom = 0.8

        self.px = 0
        self.py = 0
        self.cx = 0
        self.cy = 0

       
        self.initialy = self.y
        self.initialx = self.x

        

    

    def rectanglesCollide(self,left1, top1, width1, height1,
                      left2, top2, width2, height2):
        bottom1 = top1 + height1
        bottom2 = top2 + height2
        right1 = left1 + width1 
        right2 = left2 + width2
        return (top1 <= top2 or bottom1 >= bottom2 or left1 <= left2 or right1 >= right2)
    
    def check_top(self, top1, top2):
        return top1 <= top2
    
    def check_bottom(self, top1, height1, top2, height2):
        bottom1 = top1 + height1
        bottom2 = top2 + height2
        return bottom1 >= bottom2
    
    def check_left(self, left1, left2):
        return left1 <= left2
    
    def check_right(self, left1, width1, left2, width2):
        right1 = left1 + width1 - width1/2
        right2 = left2 + width2
        return right1 >= right2
    
    
    def update_dimensions(self):
        pass
    
    def zoom_in(self):
        if self.zoomLevel < 1.54:
            self.old_zoom = self.zoomLevel
            self.zoomLevel += 0.02
            self.update_dimensions()
            self.adjust_pos(self.old_zoom, self.zoomLevel)

    def zoom_out(self):
        if self.zoomLevel > 0.4:
            self.old_zoom = self.zoomLevel
            self.zoomLevel -= 0.02
            self.update_dimensions()
            self.adjust_pos(self.old_zoom, self.zoomLevel)

    def adjust_pos(self, old_zoom, new_zoom):
        scale = new_zoom / old_zoom
        self.x = (self.x - self.app.width // 2) * scale + self.app.width // 2
        self.y = (self.y - self.app.height // 2) * scale + self.app.height // 2

    def jump(self):
        
        
        if self.jumping:
            self.y += self.speed* self.zoomLevel * self.gravity/6

        if self.y - self.initialy > 25*self.zoomLevel and self.jumping:
            self.jumping = False
            self.falling = True
        
        if self.falling:
            self.y -= self.speed * self.zoomLevel * self.gravity/6
            if self.y <= self.initialy:
                self.falling = False
                
    
        

    def move_left(self):
        self.x -= self.speed * self.zoomLevel
        
    def move_right(self):
        self.x += self.speed * self.zoomLevel

    def move_up(self):
        self.y -= self.speed * self.zoomLevel

    def move_down(self):
        self.y += self.speed * self.zoomLevel

    def change_speed(self):
        if self.speed < self.maxSpeed and self.sprint:
            self.speed += self.acceleration * self.zoomLevel
        if self.speed > 2 and not self.sprint:
            self.speed -= self.acceleration * 2 * self.zoomLevel


class Player(CameraSystem):
    def __init__(self, app,imagesR, imagesL):
        super().__init__(app)
        self.inw = int(128 * self.screenMultiplier)
        self.inh = int(128 * self.screenMultiplier)
        self.speed = 2
        self.acceleration = 0.05
        self.maxSpeed = 5
        self.sprint = False
        self.offset_y = self.y - self.app.camera.y
        self.offset_x =  self.x - self.app.camera.x
        self.jumping = False
        self.falling = False
        self.gravity = 9.81
        

        self.idleR = [imagesR[0]]
        self.idleL = [imagesL[0]]
        self.playerR = imagesR[1:]
        self.playerL = imagesL[1:]
        
        self.direction = 'right'
        self.player = self.idleR

        self.current_image = 0
        self.state = 'idle'

        self.delay = 0.2
        self.maxDelay = 0.6
        self.delayAccel = 0.01

        self.update_dimensions()

        
    def state(self):
        return self.state
    
    def update_state(self):
        self.loop_images()
        self.change_delay()
        if self.state == 'idle':
            if self.direction == 'right':
                self.player = self.idleR
            else:
                self.player = self.idleL

        if self.state == 'walk':
            if self.direction == 'right':
                self.player = self.playerR
            else:
                self.player = self.playerL

        
        
    def loop_images(self):
        self.current_image = (self.current_image + self.delay)
        
    def change_delay(self):
            if self.delay < self.maxDelay and self.sprint:
                self.delay += self.delayAccel * self.zoomLevel
            if self.delay > 0.2 and not self.sprint:
                self.delay -= self.delayAccel * self.zoomLevel * 2

    def update_offset(self):
        self.offset_y = (self.y -  self.app.camera.y)
        self.offset_x = (self.x - self.app.camera.x)

    def update_dimensions(self):
        aspect_ratio = self.inh / self.inw
        self.w = self.inw * self.zoomLevel
        self.h = self.w * aspect_ratio


class Camera(CameraSystem):
    def __init__(self, app, w, h):
        super().__init__(app)
        self.inw = w
        self.inh = h
        self.lerp = 0.01
        self.update_dimensions()

    def update_dimensions(self):
        aspect_ratio = self.inh / self.inw
        self.w = self.inw * self.zoomLevel
        self.h = self.w * aspect_ratio

    def follow_player(self):
        
        dist_x = abs(self.app.player.x - self.x) * self.zoomLevel 
        dist_y = abs(self.app.player.y - self.y) * self.zoomLevel 
        
        
        multiplier = 1+ math.log1p(dist_x + dist_y)
    
        self.x += (self.app.player.x - self.x) * self.lerp * multiplier * self.zoomLevel
        self.y += (self.app.player.y - self.y) * self.lerp * multiplier * self.zoomLevel
