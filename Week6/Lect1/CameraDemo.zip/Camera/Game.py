from cmu_graphics import *
from cmu_graphics.shape_logic import loadImageFromStringReference as img
from Classes import *
import math



app.cam = CameraSystem(app)
def onAppStart(app):
    
    app.bg = img('BG.png')
    getImageSize(app.bg)
    app.bgw ,app.bgh= getImageSize(app.bg)
    app.bgw,app.bgh = int(app.bgw * 2*app.cam.screenMultiplier), int(app.bgh * 2*app.cam.screenMultiplier)

    app.camera = Camera(app, app.bgw, app.bgh)
    app.playerR = [img("idle_aboud_r.png"),img('walk_aboud_1_r.png'), img('walk_aboud_2_r.png'),img('walk_aboud_1_r.png'),img('walk_aboud_4_r.png')]
    app.playerL = [img("idle_aboud_l.png"),img('walk_aboud_1_l.png'), img('walk_aboud_2_l.png'),img('walk_aboud_1_l.png'),img('walk_aboud_4_l.png')]
    app.player = Player(app, app.playerR, app.playerL)

    app.clouds = img('cloud.jpg')
    app.cloudx,app.cloudy = getImageSize(app.clouds)
    app.cloudx,app.cloudy = int(app.cloudx *app.cam.screenMultiplier), int(app.cloudy* app.cam.screenMultiplier)
    app.cloudX = [0, app.cloudx]
    
   
    
def onKeyPress(app, key):
     if not app.player.check_top(app.height- app.player.y- app.player.offset_y - app.player.h/2,app.camera.y - app.camera.h / 2):
        if key in 'rR':
            app.player.initialy = app.player.y
            app.player.jumping = True
        
        

def onKeyHold(app, keys):
    print(keys)
    if 'q' in keys or 'Q' in keys:
        app.camera.zoom_in()
        app.player.zoom_in()
    if 'e' in keys or 'E' in keys:
        app.camera.zoom_out()
        app.player.zoom_out()
   

    move_mapping = {
        'd': ('move_left', 'move_right'),
        'a': ('move_right', 'move_left'),
        's': ('move_up', 'move_down'),
        'w': ('move_down', 'move_up'),
        'D': ('move_left', 'move_right'),
        'A': ('move_right', 'move_left'),
        'S': ('move_up', 'move_down'),
        'W': ('move_down', 'move_up'),
        
    }
    
 
    if any(key in keys for key in 'adws'):
        app.player.sprint =  False
            
    if any(key in keys for key in 'ADWS'):
        app.player.sprint =  True
            
    for key in keys:
        if key in move_mapping:
            app.player.state = 'walk'
            px = app.width - app.player.x - app.player.offset_x - app.player.w/2 + app.player.w/4
            py = app.height- app.player.y- app.player.offset_y - app.player.h/2
            cx = app.camera.x - app.camera.w / 2
            cy = app.camera.y - app.camera.h / 2
            
            player_move, camera_move = move_mapping[key]
                
            if not app.player.check_top(py,cy) and key in 'wW':
                app.player.up = True
                getattr(app.player, player_move)()
            if not app.player.check_bottom(py,app.player.h,cy,app.camera.h) and key in 'sS':
                getattr(app.player, player_move)()
            if not app.player.check_left(px,cx) and key in'aA':
                app.player.direction = 'left'
                getattr(app.player, player_move)()
            if not app.player.check_right(px,app.player.w,cx,app.camera.w) and key in 'dD':
                app.player.direction = 'right'
                getattr(app.player, player_move)()

                
    
def onStep(app):
    app.cloudX[0] -= 5
    app.cloudX[1] -= 5

    if app.cloudX[0] <= -app.cloudx:
        app.cloudX[0] = app.cloudX[1] + app.cloudx

    if app.cloudX[1] <= -app.cloudx:
        app.cloudX[1] = app.cloudX[0] + app.cloudx


    app.player.jump()
    app.player.update_state()
    app.player.change_speed()
    app.camera.follow_player()
    app.player.update_offset()
    app.player.state = 'idle'

def redrawAll(app):

    drawImage(app.clouds, app.cloudX[0], 0, width=app.cloudx, height=app.cloudy)
    drawImage(app.clouds, app.cloudX[1], 0, width=app.cloudx, height=app.cloudy)
    # drawRect(app.width // 2 , app.height // 2 , app.cloudx,app.cloudy, fill='steelblue', align='center')
    drawImage(app.bg, app.camera.x, app.camera.y, width=app.camera.w, height=app.camera.h, align='center')
    drawRect(app.camera.x, app.camera.y, app.camera.w, app.camera.h, fill=None, align='center', border="black", borderWidth=1)
    drawImage(app.player.player[int(app.player.current_image) % len(app.player.player)],app.width - app.player.x - app.player.offset_x,app.height - app.player.y- app.player.offset_y, width =app.player.w, height = app.player.h, align='center')
    # print("player:", app.player.x, app.player.y, "camera:", app.camera.x, app.camera.y)
    # print(app.player.speed, app.camera.speed)
   

    # Calculate camera rectangle coordinates
    


def playGame():
    runApp(width=int(1106*app.cam.screenMultiplier), height=int(741*app.cam.screenMultiplier))

def main():
    playGame()

if __name__ == '__main__':
    main()
